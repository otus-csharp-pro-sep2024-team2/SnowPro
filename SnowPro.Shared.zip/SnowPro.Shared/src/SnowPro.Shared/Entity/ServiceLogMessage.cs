﻿namespace SnowPro.Shared.Entity;

public record ServiceLogMessage (string Message, ServiceLogType LogType);

