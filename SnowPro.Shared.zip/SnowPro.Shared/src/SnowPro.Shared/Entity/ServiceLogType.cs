﻿namespace SnowPro.Shared.Entity;

public enum ServiceLogType
{
    Information, 
    Warning, 
    Error,
    Debug,
    Trace,
}